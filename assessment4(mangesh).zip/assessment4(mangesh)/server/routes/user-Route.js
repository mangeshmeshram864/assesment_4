const express = require('express');
const router = express.Router();
const userController = require('../controller/user-Controller')
const subUserController = require('../controller/subUser-Controller');

const upload = require('../middleware/uploadFile'); // Adjust the path as necessary

router.post('/register', upload.single('profile'), userController.registerUser);

const { verifToken } = require('../middleware/verifyToken');


router.post('/login', userController.loginUser)


router.post('/add_user',verifToken, subUserController.addUser)
router.get('/getsub_user', verifToken, subUserController.getAllUser)

router.put('/:id', subUserController.updateSubUser)

router.get('/get_user/:id',userController.loginUserDetails)

// router.get('/:id',)

module.exports = router;