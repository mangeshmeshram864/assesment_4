import React from "react";

function Sidebar() {
    return (
        <>
            <h2>Sidebar</h2>
        </>
    );
}

export default Sidebar;
