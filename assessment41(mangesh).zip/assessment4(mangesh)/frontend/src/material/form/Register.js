
import React, { useState } from 'react';
import axios from 'axios';
import Checkbox from '@mui/material/Checkbox';
import { useNavigate, Link } from 'react-router-dom';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';


const Register = () => {
    const [formData, setFormData] = useState({
        userName: '',
        password: '',
        fName: '',
        lName: '',
        Married_Status: false,
        gender: '',
        DOB:''
    });

    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData)
        try {
            const response = await axios.post('http://localhost:5000/api/register', formData);
            console.log('Register successful:', response.data);
            navigate('/login');
        } catch (err) {
            setError('Register failed. Please try again.');
            console.error(err);
        }
    };


  


    return (
        <div>
            <h2>Register</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>First Name:</label>
                    <input
                        type="text"
                        name="fName"
                        value={formData.fName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Last Name:</label>
                    <input
                        type="text"
                        name="lName"
                        value={formData.lName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="userName"
                        value={formData.userName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Married Status</label>
                    <Checkbox
                        name="Married_Status"
                        checked={formData.Married_Status}
                        onChange={handleChange}
                        inputProps={{ 'aria-label': 'controlled' }}
                    />
                </div>
                <div>
                    <label>DOB:</label>
                    <input
                        type="date"
                        name="DOB"
                        value={formData.DOB}
                        onChange={handleChange}
                        required
                    />
                </div>
                <input type="file" name="profile" onChange={handleChange} />
                <FormControl>
                    <FormLabel id="gender-label">Gender</FormLabel>
                    <RadioGroup
                        row
                        aria-labelledby="gender-label"
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                    >
                        <FormControlLabel value="female" control={<Radio />} label="Female" />
                        <FormControlLabel value="male" control={<Radio />} label="Male" />
                        <FormControlLabel value="other" control={<Radio />} label="Other" />
                    </RadioGroup>
                </FormControl>

                <button type="submit">Register</button>
                <div className="text-center">
                    Have an account? <Link to="/">Login</Link>
                </div>
            </form>
        </div>
    );
};

export default Register;