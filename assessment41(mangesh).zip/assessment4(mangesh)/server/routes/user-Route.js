const express = require('express');
const router = express.Router();
const userController = require('../controller/user-Controller')
const subUserController = require('../controller/subUser-Controller');

//code for multer 

const multer = require('multer');
const { verifToken } = require('../middleware/verifyToken');



//for multer storage 
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads")
    },
    filename: (req, file, cb) => {
     

        cb(null,Date.now()+Path2D.extname(file.originalname)); //append extension 
    }

})
const upload= multer({storage});
//for filter the type of img is ....

// const upload = multer({

//     fileFilter: (req, file, cb) => {
//         if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
//             cb(null, true);
//         } else {
//             cb(null, false);
//             return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
//         }
//     },
//     storage: storage,
// })

//post an image 



//code end 
router.post('/register', userController.registerUser)
router.post('/login', userController.loginUser)


router.post('/add_user',verifToken, subUserController.addUser)
router.get('/getsub_user', verifToken, subUserController.getAllUser)

router.put('/:id', subUserController.updateSubUser)

// router.get('/:id',)

module.exports = router;