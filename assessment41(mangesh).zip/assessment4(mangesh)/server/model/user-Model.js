const mongoose = require('mongoose');

// Define Item Schema
const userSchema = new mongoose.Schema({
      userName: { type: String, required: true },
      password: { type: String, required: true },
      fname:{type:String},
      lname:{type:String},
      gender:{type:String},
      DOB:{type:Date},
      Married_Status:{type:String},

      photo:{
            type:String
        }

});
// Create Item Model
const User = mongoose.model('User', userSchema);

module.exports = User;